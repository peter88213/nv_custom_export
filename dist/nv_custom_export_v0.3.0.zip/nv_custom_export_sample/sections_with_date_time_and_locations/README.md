# nv_custom_export sample template set

This template set inserts the name of the weekday, date, time, 
and location above each section.

The paragraph style of the weekday/date/time is `Heading 5`, and the
paragraph style of the location is `Heading 6`, so you might want to
edit these styles, e.g. to adjust the spacing above and below
the paragraph.    