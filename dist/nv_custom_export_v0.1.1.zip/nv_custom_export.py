"""novelibre plugin providing a custom template-based export for the final document. 

Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_custom_export
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import webbrowser

from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)



class CustomExportService:

    TEMPLATES = dict(
        _fileHeader='header.xml',
        _partTemplate='part_template.xml',
        _partEndTemplate='part_end_template.xml',
        _chapterTemplate='chapter_template.xml',
        _chapterEndTemplate='chapter_end_template.xml',
        _sectionTemplate='section_template.xml',
        _firstSectionTemplate='first_section_template.xml',
        _sectionDivider='section_divider.xml',
         )

    def set_custom_templates(self, model):
        exportClass = model.nvService.final_document_class()
        exportClass._firstSectionTemplate = '''<text:p text:style-name="Heading_20_6">$Viewpoint</text:p>\n'
$SectionContent
    '''



class Plugin(PluginBase):
    VERSION = '0.1.1'
    API_VERSION = '5.22'
    DESCRIPTION = 'Custom template-based export for the final document'
    URL = 'https://github.com/peter88213/nv_custom_export'

    HELP_URL = 'https://peter88213.github.io/nv_custom_export/nv_custom_export/'

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Extends the superclass method.
        """
        super().install(model, view, controller)

        self._ui.helpMenu.add_command(label='nv_custom_export Online help', command=self.open_help)
        customExportService = CustomExportService()
        customExportService.set_custom_templates(self._mdl)

    def open_help(self):
        webbrowser.open(self.HELP_URL)

