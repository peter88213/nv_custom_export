"""novelibre plugin providing a custom template-based export for the final document. 

Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_custom_export
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import webbrowser

from abc import ABC, abstractmethod



class SubController:

    def initialize_controller(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self.initialize_controller(model, view, controller)

import os
from pathlib import Path
from tkinter import messagebox


class CustomExportService:

    def __init__(self, model):
        self._mdl = model
        self.templateDir = None
        self.exportClass = self._mdl.nvService.final_document_class()
        self.defaultFileHeader = self.exportClass._fileHeader
        self.defaultPartTemplate = self.exportClass._partTemplate
        self.defaultPartEndTemplate = self.exportClass._partEndTemplate
        self.defaultChapterTemplate = self.exportClass._chapterTemplate
        self.defaultChapterEndTemplate = self.exportClass._chapterEndTemplate
        self.defaultSectionTemplate = self.exportClass._sectionTemplate
        self.defaultFirstSectionTemplate = self.exportClass._firstSectionTemplate
        self.defaultSectionDivider = self.exportClass._sectionDivider

    def set_template_dir(self):
        self.templateDir = f'{os.path.dirname(self._mdl.prjFile.filePath)}/nv_custom_export'
        if not os.path.isdir(self.templateDir):
            try:
                homeDir = str(Path.home()).replace('\\', '/')
                self.templateDir = os.path.join(homeDir, '.novx/nv_custom_export')
            except:
                return

            if not os.path.isdir(self.templateDir):
                return

    def set_custom_templates(self):
        self.set_template_dir()
        self.exportClass._fileHeader = self.get_template_text('header.txt', self.defaultFileHeader)
        self.exportClass._partTemplate = self.get_template_text('part_template.txt', self.defaultPartTemplate)
        self.exportClass._partEndTemplate = self.get_template_text('part_end_template.txt', self.defaultPartEndTemplate)
        self.exportClass._chapterTemplate = self.get_template_text('chapter_template.txt', self.defaultChapterTemplate)
        self.exportClass._chapterEndTemplate = self.get_template_text('chapter_end_template.txt', self.defaultChapterEndTemplate)
        self.exportClass._sectionTemplate = self.get_template_text('section_template.txt', self.defaultSectionTemplate)
        self.exportClass._firstSectionTemplate = self.get_template_text('first_section_template.txt', self.defaultFirstSectionTemplate)
        self.exportClass._sectionDivider = self.get_template_text('section_divider.txt', self.defaultSectionDivider)

    def get_template_text(self, fileName, default):
        templateText = default
        templateFile = os.path.join(self.templateDir, fileName)
        if os.path.isfile(templateFile):
            try:
                with open(templateFile, 'r', encoding='utf-8') as f:
                    templateText = f.read()
            except Exception as ex:
                messagebox.showerror(
                    title='nv_custom_export plugin',
                    message=f'Cannot load custom template: {os.path.normpath(templateFile)}',
                    detail=str(ex),
                    )
        return templateText



class Plugin(PluginBase):
    VERSION = '0.2.0'
    API_VERSION = '5.22'
    DESCRIPTION = 'Custom template-based export for the final document'
    URL = 'https://github.com/peter88213/nv_custom_export'

    HELP_URL = 'https://peter88213.github.io/nv_custom_export/help/'

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the main model instance of the application.
            view -- reference to the main view instance of the application.
            controller -- reference to the main controller instance of the application.

        Extends the superclass method.
        """
        super().install(model, view, controller)

        self._ui.helpMenu.add_command(label='nv_custom_export Online help', command=self.open_help)
        self.customExportService = CustomExportService(self._mdl)

    def on_open(self):
        self.customExportService.set_custom_templates()

    def open_help(self):
        webbrowser.open(self.HELP_URL)

