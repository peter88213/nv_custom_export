# nv_custom_export sample template set

The paragraph style of the chapter number is `Heading 5`, and the
paragraph style of the chapter title is `Heading 2`.
The chapter title is assigned an outline level, so it will
show up in the Navigator.