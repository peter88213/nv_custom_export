"""novelibre plugin for template-based export of the final document. 

Requires Python 3.6+
Copyright (c) 2025 Peter Triesberger
For further information see https://github.com/peter88213/nv_custom_export
License: GNU GPLv3 (https://www.gnu.org/licenses/gpl-3.0.en.html)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
"""
import webbrowser

from abc import ABC, abstractmethod



class SubController:

    def disable_menu(self):
        pass

    def enable_menu(self):
        pass

    def lock(self):
        pass

    def on_close(self):
        pass

    def on_open(self):
        pass

    def on_quit(self):
        pass

    def unlock(self):
        pass



class PluginBase(ABC, SubController):
    VERSION = ''
    API_VERSION = ''
    DESCRIPTION = ''
    URL = ''

    def __init__(self):
        self.filePath = None
        self.isActive = True
        self.isRejected = False

    @abstractmethod
    def install(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller

import os

from pathlib import Path

HOME_DIR = str(Path.home()).replace('\\', '/')
INSTALL_DIR = f'{HOME_DIR}/.novx'
TEMPLATE_FOLDER = 'nv_custom_export'


class ServiceBase:

    def __init__(self, model, view, controller):
        self._mdl = model
        self._ui = view
        self._ctrl = controller


class CustomExportService(ServiceBase):

    def __init__(self, model, view, controller):
        super().__init__(model, view, controller)
        self.templateDir = None
        self.exportClass = self._mdl.nvService.final_document_class()
        self.defaultAppendedSectionTemplate = self.exportClass._appendedSectionTemplate
        self.defaultFileHeader = self.exportClass._fileHeader
        self.defaultPartTemplate = self.exportClass._partTemplate
        self.defaultPartEndTemplate = self.exportClass._partEndTemplate
        self.defaultChapterTemplate = self.exportClass._chapterTemplate
        self.defaultChapterEndTemplate = self.exportClass._chapterEndTemplate
        self.defaultSectionTemplate = self.exportClass._sectionTemplate
        self.defaultFirstSectionTemplate = self.exportClass._firstSectionTemplate
        self.defaultSectionDivider = self.exportClass._sectionDivider

    def set_template_dir(self):
        try:
            self.templateDir = (
                f'{os.path.dirname(self._mdl.prjFile.filePath)}/'
                f'{TEMPLATE_FOLDER}'
            )
        except:
            self.templateDir = ''
        if not os.path.isdir(self.templateDir):
            self.templateDir = f'{INSTALL_DIR}/{TEMPLATE_FOLDER}'

    def set_custom_templates(self):
        self.set_template_dir()
        self.exportClass._appendedSectionTemplate = self.get_template_str(
            'appended_section_template.txt',
            self.defaultAppendedSectionTemplate
        )
        self.exportClass._fileHeader = self.get_template_str(
            'header.txt',
            self.defaultFileHeader
        )
        self.exportClass._partTemplate = self.get_template_str(
            'part_template.txt',
            self.defaultPartTemplate
        )
        self.exportClass._partEndTemplate = self.get_template_str(
            'part_end_template.txt',
            self.defaultPartEndTemplate
        )
        self.exportClass._chapterTemplate = self.get_template_str(
            'chapter_template.txt',
            self.defaultChapterTemplate
        )
        self.exportClass._chapterEndTemplate = self.get_template_str(
            'chapter_end_template.txt',
            self.defaultChapterEndTemplate
        )
        self.exportClass._sectionTemplate = self.get_template_str(
            'section_template.txt',
            self.defaultSectionTemplate
        )
        self.exportClass._firstSectionTemplate = self.get_template_str(
            'first_section_template.txt',
            self.defaultFirstSectionTemplate
        )
        self.exportClass._sectionDivider = self.get_template_str(
            'section_divider.txt',
            self.defaultSectionDivider
        )

    def get_template_str(self, fileName, defaultStr):
        templateStr = defaultStr
        templateFile = os.path.join(self.templateDir, fileName)
        if os.path.isfile(templateFile):
            try:
                with open(templateFile, 'r', encoding='utf-8') as f:
                    templateStr = f.read()
            except Exception as ex:
                self._ui.show_error(
                    title='nv_custom_export plugin',
                    message=(
                        'Cannot load custom template: '
                        f'{os.path.normpath(templateFile)}'
                    ),
                    detail=str(ex),
                    )
        return templateStr



class Plugin(PluginBase):
    VERSION = '5.1.0'
    API_VERSION = '5.34'
    DESCRIPTION = 'Custom template-based export for the final document'
    URL = 'https://github.com/peter88213/nv_custom_export'

    HELP_URL = 'https://peter88213.github.io/nv_custom_export/help/'

    def install(self, model, view, controller):
        """Install the plugin.
        
        Positional arguments:
            model -- reference to the novelibre main model instance.
            view -- reference to the novelibre main view instance.
            controller -- reference to the novelibre main controller instance.

        Extends the superclass method.
        """
        super().install(model, view, controller)

        self._ui.helpMenu.add_command(
            label='nv_custom_export Online help',
            command=self.open_help,
        )

        self.customExportService = CustomExportService(model, view, controller)

    def on_open(self):
        self.customExportService.set_custom_templates()

    def open_help(self):
        webbrowser.open(self.HELP_URL)

