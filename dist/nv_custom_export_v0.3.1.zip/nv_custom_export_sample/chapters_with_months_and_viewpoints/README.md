# nv_custom_export sample template set

This template set inserts the name of the chapter's 
first section's month and viewpoint character 
below the Chapter heading (or epigraph, if any).

The paragraph style of the month is `Heading 5`, and the
paragraph style of the viewpoint is `Heading 6`, so you might want to
edit this style, e.g. to adjust the spacing above and below
the paragraph.    