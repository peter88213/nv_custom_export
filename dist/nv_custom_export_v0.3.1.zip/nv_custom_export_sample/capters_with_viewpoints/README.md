# nv_custom_export sample template set

This template set inserts the name of the chapter's 
first section's viewpoint character below the 
Chapter heading (or epigraph, if any).

The paragraph style is `Heading 6`, so you might want to
edit this style, e.g. to adjust the spacing above and below
the paragraph.    