# nv_custom_export sample template set

This template set is the same as the hard-coded default setting of *novelibre*.
Each of its templates is used automatically if there isn't a user-defined template for replacement.